import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import './reportpage.css';

function ReportPage() {
    const location = useLocation();

    const dados = location.state?.formData;
    const analiseIA = location.state?.aiResult;

    if (!dados || !analiseIA) {
        return (
            <div className="report-container-error">
                <h2>Ops! Nenhum dado encontrado.</h2>
                <p>Por favor, volte e preencha o formulário primeiro.</p>
                <Link to="/home">Voltar para Home</Link>
            </div>
        );
    }

    return (
        <div className="report-container">
            <h1 className="report-title">Seu Relatório de Saúde</h1>

            <div className="report-grid">
                <div className="report-card">
                    <h3>Sua Base</h3>
                    <p><strong>Idade:</strong> {dados.idade} anos</p>
                    <p><strong>Peso:</strong> {dados.peso} kg</p>
                    <p><strong>Altura:</strong> {dados.altura} m</p>
                </div>

                <div className="report-card">
                    <h3>Seus Hábitos</h3>
                    <p><strong>Horas de Sono:</strong> {dados.sono} horas/noite</p>
                    <p><strong>Água:</strong> {dados.agua} litros/dia</p>
                </div>

                <div className="report-card full-width">
                    <h3>Sua Alimentação</h3>
                    <p>{dados.dieta}</p>
                </div>

                <div className="report-card full-width ai-section">
                    <h3>🤖 Análise da IA</h3>
                    <p>{analiseIA.analise}</p>
                </div>
            </div>

            <Link to="/home" className="back-button">Preencher Novamente</Link>
        </div>
    );
}

export default ReportPage;