import './loginpage.css';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { login } from '../../services/auth';

function Login() {
    const [inputValueEmail, setInputValueEmail] = useState('');
    const [inputValuePassword, setInputValuePassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const validateEmail = (email) => {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    const validatePassword = (pwd) => {
        return pwd.length >= 8;
    }

    const handleInputChangeEmail = (event) => {
        setInputValueEmail(event.target.value);
        setError('');
    }

    const handleInputChangePassword = (event) => {
        setInputValuePassword(event.target.value);
        setError('');
    }

    const handleSubmit = async (event) => {
        event.preventDefault();
        setError('');

        if (!validateEmail(inputValueEmail)) {
            setError('Por favor, insira um e-mail válido.');
            return;
        }

        if (!validatePassword(inputValuePassword)) {
            setError('A senha deve ter pelo menos 8 caracteres.');
            return;
        }

        setLoading(true);

        try {

            const data = await login(inputValueEmail, inputValuePassword);
            localStorage.setItem('user', JSON.stringify({ email: inputValueEmail, access_token: data.access_token }));
            navigate('/home');
        } catch (error) {
            setError('Erro ao conectar ao servidor. Tente novamente mais tarde.');
            console.error('Erro ao fazer login:', error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="all">
            <h1 className='logo'>Vida+</h1>
            <span>Um novo olhar na sua rotina!</span>
            <form onSubmit={handleSubmit} className="form-login">
                <h1>Entre em sua conta</h1>

                {error && <div className="error-message">{error}</div>}

                <input
                    type="email"
                    value={inputValueEmail}
                    onChange={handleInputChangeEmail}
                    placeholder="E-mail"
                    name='email'
                    required
                    disabled={loading}
                />
                <input
                    type="password"
                    value={inputValuePassword}
                    onChange={handleInputChangePassword}
                    placeholder="Senha"
                    name='password'
                    required
                    disabled={loading}
                />

                <button
                    className="login-button"
                    type='submit'
                    disabled={loading}
                >
                    {loading ? 'Carregando...' : 'Entrar'}
                </button>

                <Link to='/register' className='link-reg'>
                    Não tem uma conta? Cadastre-se!
                </Link>
            </form>
        </div>
    );
}

export default Login;